# Mecânico Brasil 3D — protótipo inicial

Este é o primeiro projeto-base do jogo. Ele cria uma oficina 3D simples e um carro provisório feito com formas geométricas.

## Ferramentas
- Godot Engine 4.x
- GitHub para guardar o projeto
- Android Export Templates do Godot para gerar APK

## Abrir no computador
1. Instale o Godot 4.x.
2. Extraia esta pasta.
3. No Godot, escolha **Importar** e selecione `project.godot`.
4. Pressione F6 ou F5 para executar.

## Publicar no GitHub
1. Crie um repositório chamado `mecanico-brasil-3d`.
2. Envie todos os arquivos e pastas desta pasta para a raiz do repositório.
3. Não envie a pasta `.godot/` caso ela seja criada localmente.

## Próximas etapas
1. Substituir o carro provisório por um modelo 3D próprio/licenciado em GLB.
2. Criar personagem e controles de toque.
3. Criar interação com peças e ferramentas.
4. Otimizar materiais, sombras, texturas e iluminação para Android.
5. Configurar exportação Android e gerar APK.

## Importante
O carro atual é apenas um bloco de protótipo, não uma representação fiel de um modelo comercial. O projeto ainda não está pronto para APK: é a fundação inicial que vamos evoluir.

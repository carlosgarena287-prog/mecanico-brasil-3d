extends Node3D

# Protótipo visual inicial: oficina, iluminação e carro-base.
# Os modelos detalhados serão adicionados depois como arquivos .glb.

func _ready() -> void:
    _create_world()
    _create_garage()
    _create_car()
    _create_camera()

func _create_world() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.48, 0.52, 0.60)
    env.ambient_light_energy = 0.55
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world.environment = env
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

func _material(color: Color, metallic: float = 0.0, roughness: float = 0.7) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = metallic
    mat.roughness = roughness
    return mat

func _box(parent: Node3D, name: String, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = size
    var instance := MeshInstance3D.new()
    instance.name = name
    instance.mesh = mesh
    instance.position = pos
    instance.material_override = mat
    parent.add_child(instance)
    return instance

func _create_garage() -> void:
    var concrete := _material(Color(0.24, 0.26, 0.29), 0.05, 0.88)
    var wall := _material(Color(0.68, 0.70, 0.72), 0.0, 0.92)
    var dark := _material(Color(0.075, 0.085, 0.10), 0.15, 0.7)
    var yellow := _material(Color(0.95, 0.62, 0.08), 0.15, 0.5)

    _box(self, "Piso da oficina", Vector3(18, 0.3, 14), Vector3(0, -0.15, 0), concrete)
    _box(self, "Parede fundo", Vector3(18, 5, 0.35), Vector3(0, 2.5, -7), wall)
    _box(self, "Parede esquerda", Vector3(0.35, 5, 14), Vector3(-9, 2.5, 0), wall)
    _box(self, "Parede direita", Vector3(0.35, 5, 14), Vector3(9, 2.5, 0), wall)

    # Faixa visual de segurança no piso
    _box(self, "Faixa amarela 1", Vector3(0.12, 0.02, 10), Vector3(-3.6, 0.02, 0), yellow)
    _box(self, "Faixa amarela 2", Vector3(0.12, 0.02, 10), Vector3(3.6, 0.02, 0), yellow)

    # Portão frontal escuro
    _box(self, "Portao", Vector3(7, 3.6, 0.22), Vector3(0, 1.8, 6.85), dark)

    var lamp := OmniLight3D.new()
    lamp.position = Vector3(0, 4.2, 0)
    lamp.light_color = Color(1.0, 0.88, 0.68)
    lamp.light_energy = 2.2
    lamp.omni_range = 13
    add_child(lamp)

func _create_car() -> void:
    var car := Node3D.new()
    car.name = "Carro_Projeto_Celta"
    car.position = Vector3(0, 0.55, 0)
    add_child(car)

    var red := _material(Color(0.62, 0.035, 0.025), 0.72, 0.24)
    var glass := _material(Color(0.035, 0.075, 0.10), 0.35, 0.16)
    var rubber := _material(Color(0.018, 0.02, 0.023), 0.0, 0.92)
    var metal := _material(Color(0.55, 0.58, 0.62), 0.85, 0.25)
    var lamp_mat := _material(Color(0.92, 0.88, 0.68), 0.15, 0.25)

    _box(car, "Carroceria", Vector3(2.05, 0.62, 4.0), Vector3(0, 0.55, 0), red)
    _box(car, "Teto", Vector3(1.72, 0.72, 2.0), Vector3(0, 1.18, -0.15), red)
    _box(car, "Parabrisa", Vector3(1.62, 0.55, 0.08), Vector3(0, 1.18, 0.88), glass)
    _box(car, "Vidro_traseiro", Vector3(1.62, 0.5, 0.08), Vector3(0, 1.18, -1.18), glass)

    for x in [-1.05, 1.05]:
        for z in [-1.3, 1.3]:
            var wheel := MeshInstance3D.new()
            wheel.name = "Pneu"
            var cyl := CylinderMesh.new()
            cyl.top_radius = 0.39
            cyl.bottom_radius = 0.39
            cyl.height = 0.22
            wheel.mesh = cyl
            wheel.rotation_degrees.z = 90
            wheel.position = Vector3(x, 0.0, z)
            wheel.material_override = rubber
            car.add_child(wheel)

            var hub := MeshInstance3D.new()
            var hub_mesh := CylinderMesh.new()
            hub_mesh.top_radius = 0.19
            hub_mesh.bottom_radius = 0.19
            hub_mesh.height = 0.235
            hub.mesh = hub_mesh
            hub.rotation_degrees.z = 90
            hub.position = Vector3(x * 1.01, 0.0, z)
            hub.material_override = metal
            car.add_child(hub)

    _box(car, "Farol_esquerdo", Vector3(0.42, 0.18, 0.08), Vector3(-0.68, 0.63, 2.04), lamp_mat)
    _box(car, "Farol_direito", Vector3(0.42, 0.18, 0.08), Vector3(0.68, 0.63, 2.04), lamp_mat)

func _create_camera() -> void:
    var camera := Camera3D.new()
    camera.position = Vector3(8.5, 6.5, 10.5)
    camera.look_at(Vector3(0, 0.7, 0), Vector3.UP)
    camera.current = true
    camera.fov = 58
    add_child(camera)

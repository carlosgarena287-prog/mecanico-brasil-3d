extends Node3D

var pivot: Node3D
var camera: Camera3D
var hood: Node3D
var hood_open := false
var dragging := false
var last_pos := Vector2.ZERO
var yaw := 0.0
var pitch := -0.18
var distance := 8.5
var money := 1250
var repaired := false
var status_label: Label
var money_label: Label
var action_label: Label

func mat(c: Color, metal := 0.0, rough := 0.65) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metal
	m.roughness = rough
	return m

func box(parent: Node3D, label: String, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var n := MeshInstance3D.new()
	n.name = label
	n.mesh = mesh
	n.position = pos
	n.material_override = material
	parent.add_child(n)
	return n

func cylinder(parent: Node3D, label: String, radius: float, height: float, pos: Vector3, material: Material) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 32
	var n := MeshInstance3D.new()
	n.name = label
	n.mesh = mesh
	n.position = pos
	n.material_override = material
	parent.add_child(n)
	return n

func _ready() -> void:
	build_world()
	build_garage()
	build_car()
	build_camera()
	build_ui()
	update_ui()

func build_world() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.035, 0.047, 0.065)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.58, 0.62, 0.7)
	env.ambient_light_energy = 0.75
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	add_child(sun)

func build_garage() -> void:
	var floor_mat := mat(Color(0.20,0.22,0.25),0.05,0.9)
	var wall_mat := mat(Color(0.34,0.37,0.41),0.0,0.9)
	var dark := mat(Color(0.045,0.055,0.068),0.2,0.6)
	var yellow := mat(Color(0.95,0.61,0.07),0.1,0.5)
	box(self,"Piso",Vector3(18,0.25,16),Vector3(0,-0.15,0),floor_mat)
	box(self,"Parede do fundo",Vector3(18,5.5,0.25),Vector3(0,2.6,-7.9),wall_mat)
	box(self,"Parede esquerda",Vector3(0.25,5.5,16),Vector3(-9,2.6,0),wall_mat)
	box(self,"Parede direita",Vector3(0.25,5.5,16),Vector3(9,2.6,0),wall_mat)
	box(self,"Portao",Vector3(6.5,4.1,0.18),Vector3(0,2,-7.68),dark)
	for i in range(8):
		box(self,"Lamina %d" % i,Vector3(6.35,0.035,0.035),Vector3(0,0.25+i*0.48,-7.56),mat(Color(0.2,0.22,0.25)))
	box(self,"Faixa de seguranca",Vector3(18,0.08,0.12),Vector3(0,0.01,-7.72),yellow)
	for x in [-5.5,0.0,5.5]:
		var lamp := OmniLight3D.new()
		lamp.position=Vector3(x,4.7,-1)
		lamp.light_color=Color(1,0.83,0.62)
		lamp.light_energy=2.0
		lamp.omni_range=9
		add_child(lamp)
		box(self,"Luminaria",Vector3(2.2,0.08,0.55),Vector3(x,5.15,-1),mat(Color(0.92,0.88,0.72)))
	box(self,"Bancada",Vector3(3.8,0.18,0.9),Vector3(-6.5,1.05,-4.6),mat(Color(0.12,0.14,0.17),0.35))
	box(self,"Armario vermelho",Vector3(1.3,1.8,0.7),Vector3(-7.6,0.9,-5.2),mat(Color(0.68,0.12,0.08),0.25))
	box(self,"Painel de ferramentas",Vector3(3.5,1.25,0.12),Vector3(-6.5,2,-5.15),dark)
	for x in [-2.3,2.3]:
		box(self,"Coluna elevador",Vector3(0.22,3.2,0.22),Vector3(x,1.5,0.3),yellow)
		box(self,"Braco elevador",Vector3(1.15,0.14,0.2),Vector3(x*0.65,0.45,0.3),dark)

func build_car() -> void:
	var car := Node3D.new()
	car.name="Celta_2013_provisorio"
	car.position=Vector3(0,0.12,-0.4)
	add_child(car)
	var red:=mat(Color(0.62,0.035,0.045),0.62,0.24)
	var glass:=mat(Color(0.055,0.11,0.15),0.25,0.18)
	var rubber:=mat(Color(0.018,0.02,0.023),0.05,0.88)
	var metal:=mat(Color(0.58,0.62,0.66),0.85,0.22)
	var dark:=mat(Color(0.035,0.04,0.045),0.25,0.5)
	var lamp:=mat(Color(0.95,0.88,0.66),0.15,0.2)
	box(car,"Carroceria",Vector3(2,0.62,4.05),Vector3(0,0.72,0),red)
	box(car,"Teto",Vector3(1.72,0.16,1.75),Vector3(0,1.88,0.05),red)
	box(car,"Para-brisa",Vector3(1.65,0.66,0.08),Vector3(0,1.51,-0.91),glass).rotation.x=deg_to_rad(-17)
	box(car,"Vidro traseiro",Vector3(1.62,0.62,0.08),Vector3(0,1.52,1.02),glass).rotation.x=deg_to_rad(17)
	for x in [-0.88,0.88]:
		box(car,"Vidro lateral",Vector3(0.07,0.58,1.55),Vector3(x,1.55,0.06),glass)
		box(car,"Coluna lateral",Vector3(0.09,0.78,1.82),Vector3(x*1.02,1.55,0.05),red)
	box(car,"Parachoque dianteiro",Vector3(2.02,0.24,0.22),Vector3(0,0.58,-2.08),dark)
	box(car,"Parachoque traseiro",Vector3(2.02,0.24,0.22),Vector3(0,0.58,2.08),dark)
	for x in [-0.68,0.68]:
		box(car,"Farol",Vector3(0.48,0.2,0.07),Vector3(x,0.91,-2.19),lamp)
		box(car,"Lanterna",Vector3(0.38,0.28,0.07),Vector3(x,0.88,2.19),mat(Color(0.7,0.025,0.02)))
	for x in [-1.02,1.02]:
		for z in [-1.35,1.35]:
			var w:=cylinder(car,"Pneu",0.43,0.23,Vector3(x,0.48,z),rubber)
			w.rotation.z=PI/2
			var h:=cylinder(car,"Roda",0.24,0.245,Vector3(x*1.01,0.48,z),metal)
			h.rotation.z=PI/2
	for x in [-1.05,1.05]:
		box(car,"Retrovisor",Vector3(0.22,0.16,0.26),Vector3(x,1.42,-0.65),red)
	# Capo independente para animacao
	hood=Node3D.new()
	hood.name="Capo_interativo"
	hood.position=Vector3(0,1.16,-1.35)
	car.add_child(hood)
	box(hood,"Peca do capo",Vector3(1.94,0.12,1.12),Vector3.ZERO,red)
	box(car,"Grade frontal",Vector3(0.7,0.16,0.06),Vector3(0,0.79,-2.2),dark)

func build_camera() -> void:
	pivot=Node3D.new()
	pivot.position=Vector3(0,1,0)
	add_child(pivot)
	camera=Camera3D.new()
	pivot.add_child(camera)
	camera.current=true
	update_camera()

func update_camera() -> void:
	pivot.rotation=Vector3(pitch,yaw,0)
	camera.position=Vector3(0,1.5,distance)
	camera.look_at(Vector3(0,1,0),Vector3.UP)

func build_ui() -> void:
	var layer:=CanvasLayer.new()
	add_child(layer)
	var panel:=PanelContainer.new()
	panel.position=Vector2(18,18)
	panel.custom_minimum_size=Vector2(310,112)
	layer.add_child(panel)
	var v:=VBoxContainer.new()
	panel.add_child(v)
	var title:=Label.new()
	title.text="MECÂNICO BRASIL 3D"
	title.add_theme_font_size_override("font_size",23)
	title.add_theme_color_override("font_color",Color(1,0.72,0.18))
	v.add_child(title)
	status_label=Label.new()
	v.add_child(status_label)
	money_label=Label.new()
	v.add_child(money_label)
	var row:=HBoxContainer.new()
	row.position=Vector2(18,145)
	layer.add_child(row)
	add_button(row,"Abrir capô",toggle_hood)
	add_button(row,"Inspecionar",inspect_car)
	add_button(row,"Consertar",repair_car)
	var help:=Label.new()
	help.text="Arraste a tela para girar a câmera • Botões para trabalhar"
	help.position=Vector2(18,210)
	help.add_theme_font_size_override("font_size",17)
	layer.add_child(help)
	action_label=Label.new()
	action_label.position=Vector2(18,250)
	action_label.add_theme_font_size_override("font_size",19)
	action_label.add_theme_color_override("font_color",Color(0.72,0.92,0.76))
	layer.add_child(action_label)

func add_button(parent: Control, text_value: String, action: Callable) -> void:
	var b:=Button.new()
	b.text=text_value
	b.custom_minimum_size=Vector2(145,54)
	b.add_theme_font_size_override("font_size",21)
	b.pressed.connect(action)
	parent.add_child(b)

func update_ui() -> void:
	if is_instance_valid(status_label):
		status_label.text="Veículo: Celta 2013 | "+("Capô aberto" if hood_open else "Capô fechado")
		money_label.text="Caixa da oficina: R$ %d" % money

func toggle_hood() -> void:
	hood_open=not hood_open
	hood.rotation.x=deg_to_rad(-58) if hood_open else 0.0
	action_label.text="Capô aberto. Agora você pode inspecionar o motor." if hood_open else "Capô fechado."
	update_ui()

func inspect_car() -> void:
	if hood_open:
		action_label.text="Diagnóstico: bateria fraca e óleo precisa de verificação."
	else:
		action_label.text="Abra o capô para acessar o compartimento do motor."

func repair_car() -> void:
	if not hood_open:
		action_label.text="Primeiro abra o capô."
	elif repaired:
		action_label.text="Serviço concluído. Aguarde outro cliente."
	else:
		repaired=true
		money+=350
		action_label.text="Reparo concluído! Você recebeu R$ 350."
		update_ui()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		dragging=event.pressed
		last_pos=event.position
	elif event is InputEventScreenDrag and dragging:
		var d:=event.position-last_pos
		last_pos=event.position
		yaw-=d.x*0.006
		pitch=clamp(pitch-d.y*0.003,-0.65,0.12)
		update_camera()
	elif event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
		dragging=event.pressed
		last_pos=event.position
	elif event is InputEventMouseMotion and dragging:
		var d:=event.position-last_pos
		last_pos=event.position
		yaw-=d.x*0.006
		pitch=clamp(pitch-d.y*0.003,-0.65,0.12)
		update_camera()
	elif event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_WHEEL_UP:
		distance=max(5.5,distance-0.5)
		update_camera()
	elif event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_WHEEL_DOWN:
		distance=min(12.0,distance+0.5)
		update_camera()

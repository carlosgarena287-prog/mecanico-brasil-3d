# Mecânico Brasil 3D — Protótipo v0.2

## Novidades desta versão
- Oficina 3D procedural com piso, paredes, portão, iluminação, bancada e elevador.
- Carro compacto provisório inspirado no Celta 2013.
- Câmera que gira ao arrastar a tela.
- Interface com caixa da oficina.
- Capô que abre e fecha.
- Diagnóstico simples e reparo que adiciona R$ 350 ao caixa.

## Como abrir
Extraia o ZIP e abra `project.godot` no Godot 4.x.

## Estado do projeto
Este é um protótipo jogável em evolução, ainda não é um APK final. O carro é um modelo provisório feito com formas geométricas. A próxima etapa será criar motor e peças separados, melhorar o modelo do Celta e transformar os reparos em tarefas interativas.
